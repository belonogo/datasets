y=9999+1
z=9999
while z!=1315:
    y=y-1
    q=str(y)
    a=int(q[0])+int(q[1])
    s=int(q[1])+int(q[2])
    d=int(q[2])+int(q[3])
    w=min(a,s,d)
    print('Проверю число:',y)
    if a==w:
        z=str(min(s,d))+str(max(s,d))
        z=int(z)
        print(z)
    elif s==w:
        z=str(min(a,d))+str(max(a,d))
        z=int(z)
        print(z)
    elif d==w:
        z=str(min(s,a))+str(max(s,a))
        z=int(z)
        print(z)
print('')
print('По итору наибольшим оказался: ',y)
