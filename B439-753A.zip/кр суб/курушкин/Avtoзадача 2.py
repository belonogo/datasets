R=1
y=0
while R<151:
    y=y+1
    q=y
    e=q
    w=''
    o=''
    R=0
    print('Проверю число',y)
    while q>0:
        p=q%2
        q=q//2
        w=w+str(p)
    w=w[::-1]
    if e%3==0:
        N=w+w[-3::]
        print('(Из алгоритма)')
        print(str(e)+' В десятичной = '+str(N)+' В двоичной')
        N=N[::-1]
        for i in range (len(N)):
            R=R+int(N[i])*2**i
        N=N[::-1]
        print(str(N)+' В двоичной = '+str(R)+' В десятичной')
        print('')
    else:
        E=(e%3)*3
        while E>0:
            p=E%2
            E=E//2
            o=o+str(p)
        o=o[::-1]
        N=w+o
        print('(Из алгоритма)')
        print(str(e)+' В десятичной = '+str(N)+' В двоичной')
        N=N[::-1]
        for i in range (len(N)):
            R=R+int(N[i])*2**i
        N=N[::-1]
        print(str(N)+' В двоичной = '+str(R)+' В десятичной')
        print('')
print('По итору R =',R)
