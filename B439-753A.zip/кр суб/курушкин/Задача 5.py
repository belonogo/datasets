q=4*3*2*1*4
q=q*4
w=4*3*2*3*2
a=w
w=w*6
w=w*2
w=w+a
print('Ответ:',w)
