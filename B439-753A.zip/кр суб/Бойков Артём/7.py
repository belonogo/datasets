for x in range(8):
    for y in range(8):
        s= (y*11**4 + 4*11**2 + x*11+5)+(2*8**4 + 5*8**3 + 3*8**2 + x*8 + y)
        if s % 117 == 0:
            #print(s, x, y)
            print(s//117)
 
