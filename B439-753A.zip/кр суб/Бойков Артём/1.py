print('x y z w u')
for x in range(2):
    for y in range(2):
        for z in range(2):
            for w in range(2):
                for u in range(2):
                    if (((x<=y) and (z == (not(w)))) <= (u == (x or z))) == False:
                        print(x, y, z, w, u)


'''x y z w u
0 0 0 1 1
0 0 1 0 0
0 1 1 0 0
1 1 0 1 0

w z y x u
0 1 0 0 0
0 1 1 0 0
1 0 0 0 1
1 0 1 1 0'''
print(f'Ответ: wzyxu')


