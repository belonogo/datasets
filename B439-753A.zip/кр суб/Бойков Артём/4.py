from itertools import *

k=0
for x in product('КОНФЕТА',repeat = 5):
    if x.count('Е') == 2 and x[1] != 'Ф':
        k+=1
print(k)

