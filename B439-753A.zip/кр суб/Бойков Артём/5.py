from itertools import *

gl = ['Я', 'О', 'А']
sogl = ['Р', 'С', 'Л', 'В']
k = 0
for x in permutations('ЯРОСЛАВ', 5):
    k_sogl = 0
    k_gl = 0
    for i in range(len(x)-2):
        if (x[i] not in gl) and (x[i+1] in gl) and (x[i+2] not in gl):
            k_gl+=1
        else:
            k_sogl+=1
    if k_sogl > k_gl:
        k+=1
print(k)
