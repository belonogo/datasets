from itertools import *

k =1
for x in product('АГЛОЬ', repeat = 5):
    if x == ('О', 'Л', 'Ь', 'Г', 'А'):
        print(k)
        break
    else:
        k+=1
        
