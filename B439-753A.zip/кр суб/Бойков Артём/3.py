for x in range(1000, 10000):
    s1 = int(str(x)[0])+int(str(x)[1])
    s2 = int(str(x)[1])+int(str(x)[2])
    s3 = int(str(x)[2])+int(str(x)[3])
    l = [s1, s2, s3]
    l.remove(min(l))
    x_new = str(min(l)) + str(max(l))
    print(x)
    if x_new == '1315':   
        print(x)
        break
#(Ответ: 1496)
