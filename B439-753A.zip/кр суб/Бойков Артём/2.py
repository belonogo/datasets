l_tmp = []
for N in range(1, 10000):
    N_bin = bin(N)[2:]
    if N % 3 == 0:
        N_bin = str(N_bin) + str(N_bin)[-3:]
        l_tmp.append(int(N_bin, 2))
    else:
        ost = bin((N%3)*3)[2:]
        N_bin = str(N_bin) + str(ost)
        l_tmp.append(int(N_bin, 2))
l = [x for x in l_tmp if x>151]
print(min(l))
    
