from itertools import product
count=0
for p in product ('КОНФЕТА', repeat = 5 ):
    if p.count('Е') == 2 and p[1]!='Ф':
        count +=1
print(count)
