from itertools import product
data = list(product('АГЛОЬ', repeat=5))
res = data.index(('О', 'Л' , 'Ь' , 'Г' , 'А' ))
print(res + 1 )
