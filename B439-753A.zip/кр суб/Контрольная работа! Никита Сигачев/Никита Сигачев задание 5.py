from itertools import *

k=0

for x in permutations('ЯРОСЛАВ', r=5):
    s = ''.join(x)
    s = s.replace('О','Я').replace('А','Я')
    s = s.replace('С','Р').replace('Л','Р').replace('В','Р')
    if s.count('Р')>s.count('Я') and 'ЯЯ' not in s:
        k+=1
print(k)
