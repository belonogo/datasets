for x in '0123456789':
    t= int('1'+x+'BAD',16)+int('2C'+x+'FE',16)
    if t%15==0:
        print(t//15)
        break
