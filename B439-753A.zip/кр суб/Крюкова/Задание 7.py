a='01234567'
for x in a:
    for y in a:
        t=int (f'{y}04{x}5',11)+int(f'253{x}{y}',8)
        if t%117==0:
            print(t//117)
