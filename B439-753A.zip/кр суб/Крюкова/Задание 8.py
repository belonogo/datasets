for x in '0123456789':
    t=int('3'+x+'DA',14)+int('5'+x+'A6',12)
    if t%81==0:
        print(t//81)
        break

    
