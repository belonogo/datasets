for N in range(100):
    s=bin(N)[2:]# перевод в двоичную систему
    s= str(s)
    if N%3==0:
        s+= s[-3:]
    else:
        k=(N%3)*3
        s+=bin(k)[2:]
    r= int (s,2)# перевод в десятичную систему
    if r>=151 :
        print (N)
        break
