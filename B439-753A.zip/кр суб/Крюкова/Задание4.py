a={0:"К",1:"О",2:"Н",3:"Ф",4:"Е",5:"Т",6:"А"}
for g in range(0,len(a)):
    for d in range(0,len(a)):
        for b in range(0,len(a)):
            for i in range(0,len(a)):
                for n in range(0,len(a)):
                    s=a[g]+a[d]+a[b]+a[i]+a[n]
                    if a[d]!='Ф' and s.count ('Е')==2:
                        count+=1
print(count)
