for i in range(1000, 9999):
    i=str(i)
    summ12=int(i[0])+int(i[1])
    summ23=int(i[1])+int(i[2])
    summ34=int(i[2])+int(i[3])
    minsumm=min(summ12, summ23, summ34)
    n=(str(summ12)+str(summ23)+str(summ34)-str(minsumm))
print(n)
