sum = []
alph = '0123456789ABCDEF'
for x in alph:
    op1 = int('1' + x + 'BAD', 16)
    op2 = int('2C' + x + 'FE', 16)
    s = op1 + op2
    if s % 15 == 0:
        sum.append(s)
if sum:
    print(min(sum)//15)
