sum = []
alph = '0123456789ABCDEFGHIJKL'
for x in alph:
    op1 = int('63' + x + '59685', 22)
    op2 = int('17' + x + '53', 22)
    op3 = int('36' + x + '5', 22)
    s = op1 + op2 + op3
    if s % 21 == 0:
        sum.append(s)
if sum:
    print(min(sum)//21)
