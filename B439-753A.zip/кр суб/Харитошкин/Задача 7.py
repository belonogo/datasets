alph = '0123456789AB'
for x in alph:
    op1 = int('3' + x + 'DA', 14)
    op2 = int('5' + x + 'A6', 12)
    sum = op1 + op2
    if sum % 81 == 0:
        print(sum//81)
