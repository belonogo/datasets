for i in range(9999, 1001, -1):
    s = str(i)
    sm1 = int(s[0]) + int(s[1])
    sm2 = int(s[1]) + int(s[2])
    sm3 = int(s[2]) + int(s[3])
    f1 = str(sm1 + sm2 + sm3 - max(sm1, sm2, sm3) - min(sm1, sm2, sm3))
    f2 = str(max(sm1, sm2, sm3))
    sum = f1 + f2
    if sum == '1315':
        print(i)
        break
