alph = '01234567'
for x in alph:
    for y in alph:
        op1 = int(y + '04' + x + '5', 11)
        op2 = int('253' + x + y, 8)
        sum = op1 + op2
        if sum % 117 == 0:
            print(sum//117)
