n = 12
while True:
    sn = bin(n)
    sn = sn[2:]
    if n % 3 == 0:
        sn += sn[len(sn) - 3:]
    else:
        o = bin((n % 3) * 3)
        o = o[2:]
        sn += o

    r = int(sn, 2)

    if r > 151:
        print(int(sn, 2))
        break
    n += 1
    sn = ''
