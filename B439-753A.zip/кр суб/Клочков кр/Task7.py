alph = '01234567'
res = 1000000000000000
for x in alph:
    for y in alph:
        num1 = y + '04' + x + '5'
        num2 = '253' + x + y

        sm = int(num1, 11) + int(num2, 8)

        if sm % 117 == 0 and sm < res:
            res = sm
print(res/117)
