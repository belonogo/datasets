n = 1
alph = 'АГЛОЬ'
for l1 in alph:
    for l2 in alph:
        for l3 in alph:
            for l4 in alph:
                for l5 in alph:
                    res = l1 + l2 + l3 + l4 + l5

                    if res == 'ОЛЬГА':
                        print(n)
                    n += 1
                    