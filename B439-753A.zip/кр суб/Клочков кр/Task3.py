n = 1000
res = 0
while True:
    l = []
    sn = str(n)
    l.append(int(sn[0]) + int(sn[1]))
    l.append(int(sn[1]) + int(sn[2]))
    l.append(int(sn[2]) + int(sn[3]))

    ind = l.index(min(l))
    l.pop(ind)

    l.sort()

    s = ''

    for i in l:
        s += str(i)

    if int(s) == 1315 and n > res:
        res = n

    if n == 9999:
        break

    n += 1
print(res)
