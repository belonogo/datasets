n = 0
alph = 'КОНФЕТА'
for l1 in alph:
    for l2 in alph:
        for l3 in alph:
            for l4 in alph:
                for l5 in alph:
                    res = l1 + l2 + l3 + l4 + l5
                    if res.count('Е') == 2 and res[1] != 'Ф':
                        n += 1
print(n)
