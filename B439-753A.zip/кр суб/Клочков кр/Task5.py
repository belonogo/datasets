n = 0
alph = 'ЯРОСЛАВ'
for l1 in alph:
    for l2 in alph:
        for l3 in alph:
            for l4 in alph:
                for l5 in alph:
                    res = l1 + l2 + l3 + l4 + l5

                    isRep = False
                    for i in res:
                        if res.count(i) > 1:
                            isRep = True
                            break

                    sogl = 'РСЛВ'
                    gl = 'ЯОА'
                    sumSogl = 0
                    sumGl = 0

                    for i in sogl:
                        sumSogl += res.count(i)
                    for i in gl:
                        sumGl += res.count(i)

                    isMax = False

                    if sumGl >= sumSogl:
                        isMax = True

                    isContain = False

                    for a1 in gl:
                        for a2 in gl:
                            pair = a1 + a2
                            if res.count(pair) > 0:
                                isContain = True

                    if not isContain and not isRep and not isMax:
                        n += 1
print(n)
