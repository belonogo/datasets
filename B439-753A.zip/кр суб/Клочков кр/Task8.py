alph = '0123456789AB'
for x in alph:
    num1 = '3' + x + 'DA'
    num2 = '5' + x + 'A6'

    sm = int(num1, 14) + int(num2, 12)

    if sm % 81 == 0:
        print(sm / 81)
        break
    