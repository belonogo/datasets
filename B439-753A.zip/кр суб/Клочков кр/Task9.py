alph = '0123456789ABCDEF'
for x in alph:
    num1 = '1' + x + 'BAD'
    num2 = '2C' + x + 'FE'

    sm = int(num1, 16) + int(num2, 16)

    if sm % 15 == 0:
        print(sm / 15)
        break
