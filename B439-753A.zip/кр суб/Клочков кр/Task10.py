alph = '0123456789ABCDEFGHIJKL'
for x in alph:
    num1 = '63' + x + '59685'
    num2 = '17' + x + '53'
    num3 = '36' + x + '5'

    sm = int(num1, 22) + int(num2, 22) + int(num3, 22)

    if sm % 21 == 0:
        print(sm / 21)
        break
