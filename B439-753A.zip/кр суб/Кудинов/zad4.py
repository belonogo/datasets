s = 0
alph = 'КОНФЕТА'
for a1 in alph:
    for a2 in alph:
        for a3 in alph:
            for a4 in alph:
                for a5 in alph:
                    res = a1+a2+a3+a4+a5
                    if res.count('Е')==2:
                        if a1=='Ф' or a3=='Ф' or a4=='Ф' or a5=='Ф':
                            s+=1
print (s)
                        
