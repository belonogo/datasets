s = 0
n = 1
alph='ОЛЬГА'
for a1 in alph:
    for a2 in alph:
        for a3 in alph:
            for a4 in alph:
                for a5 in alph:
                    res=a1+a2+a3+a4+a5
                    while res=='ОЛЬГА':
                        print(res+n+=1)

