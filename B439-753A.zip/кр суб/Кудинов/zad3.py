for i in range (1000, 10000):
    s = str(i)
    sum12 = int(s[0])+int(s[1])
    sum23 = int(s[1])+int(s[2])
    sum34 = int(s[2])+int(s[3])
    r = str(max(sum12,sum23))+str(max(sum23,sum34))
    if r =='1315':
        print (i)
        break
