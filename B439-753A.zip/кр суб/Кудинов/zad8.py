r_list=[]
alph='0123456789ABCD'
for x in alph:
    op1=int('3'+ x+ D+ A,14)
    op2=int('5'+ x+ A+ '6',12)
    r = op1+op2
    if r%81==0:
        r_list.append(r//81)
print(r_list)
