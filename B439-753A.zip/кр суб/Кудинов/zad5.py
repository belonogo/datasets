s = 0
alph= 'ЯРОСЛАВ'
for a1 in alph:
    for a2 in alph:
        for a3 in alph:
            for a4 in alph:
                for a5 in alph:
                    res= a1+a2+a3+a4+a5
                    if a1=='Я' or a3=='Я' or a5=='Я' or a1=='О' or a3=='О' or a5=='О' or a1=='А' or a3=='А' or a5=='А':
                        if res.count('Я')==1 and res.count('О')==1 and res.count('А')==1:
                            s+=1
print(s)
