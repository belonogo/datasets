#задача1
print('x','y','z','w','u')
for x in range(2):
    for y in range(2):
        for z in range(2):
            for w in range(2):
                for u in range(2):
                    F = int(((x <= y) and (z ==(not(w)))) <= (u == (x or z)))
                    if F == 0 and w == 1 and u == 1:
                        print(x,y,z,w,u)
'''0   1   0   0   0
   0   1   1   0   0
   1   0   0   0   1
   1   0   1   1   0
   w   z   y   x   u'''
#Ответ: wzxyu.