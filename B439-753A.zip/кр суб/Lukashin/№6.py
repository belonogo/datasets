a = 'АГЛОЬ'
c = 0
s = ''
for s1 in a:
    for s2 in a:
        for s3 in a:
            for s4 in a:
                for s5 in a:
                    s = s1 + s2 + s3 + s4 + s5
                    c += 1
                    #print(s, c)
                    if s == 'ОЛЬГА':
                        print(c)
#Ответ: 2231.