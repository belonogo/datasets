for N in range(1, 101):
    R = bin(N)[2:]
    if N % 3 == 0:
        R1 = R + R[(len(R)-3): (len(R))]
    else:
        R1 = R + bin((N%3)*3)[2:]
    N1 = int(R1, 2)
    #print(N, R, R1, N1)
    if N1 > 151:
        print(N, R1, N1)
#Ответ: R1=10100110; N1=166