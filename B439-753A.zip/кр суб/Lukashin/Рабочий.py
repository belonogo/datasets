'''or N in range(100):
    R = bin(N)[2:]
    if R.count('1') % 2 == 0:
        N1 = N * 4
    else:
        N1 = (N * 2 + 1) * 2 + 1
    if N1 > 114:
        print(R)
# min R = 11100'''
'''for N in range(100):
    R = bin(N)[2:]
    for i in range(2):
        R = R + str(R.count('1') % 2)
    N1 = int(R, 2)
    if N1 > 97:
        print('R =',R)
        print("N1 =",N1)
# min N1 = 102'''
'''for N in range(10,10000):
    R = bin(N)[2:-1]
    N1 = int(R, 2)
#    print(R)
    if N % 2 == 0:
        N1 = N1 * 4 + 1
    else:
        N1 = (N1 * 2 + 1) * 2
    if N1 == 2017:
        print(N)
# N = 1008'''
'''s = '5'*54 + '7'
while s.count('557') > 0 or s.count('722') > 0:
    s = s.replace('557', '72')
    s = s.replace('722', '57')
print(s)
# s = 572'''
'''s = '1' + 98*'9'
while (s.count('19') or s.count('299') or s.count('3999')) > 0:
    s = s.replace('19', '2')
    s = s.replace('299', '3')
    s = s.replace('3999', '1')
print(s)
# s = 29'''
'''for x in '0123456789ABCDEFGHI':
    a = int('321' + x + '4', 19)
    b = int('498' + x + '9', 19)
    c = a + b
    if c % 23 == 0:
        print(c / 23)
# c/23 = 43100; x = 9'''
'''for x in range(13):
    a = int('8' + str(x) + '71', 13)
    b = int('3' + str(x) + 'DF', 17)
    c = a + b
    if c % 197 == 0:
        print(x, c / 197)
# c/197 = 175; x = 4'''
'''
c = '1115'
a,b = c[0:2],c[2:]
print(a,b)
s = []
for x in range(1,10):
    for y in range(1,10):
        for z in range(1,10):
            if x + y == int(a) and y + z == int(b):
                c1 = int(str(x) + str(y) + str(z))
                s.append(c1)
print(min(s))
#c1 = 296'''
'''c = '1715'
a,b = c[0:2],c[2:]
print(a,b)
s = 0
for x in range(1,10):
    for y in range(1,10):
        for z in range(1,10):
            if x + y == int(a) and y + z == int(b):
#               c1 = int(str(x) + str(y) + str(z))
                s+=1
print(s)'''