for x in range(22):
    c = int('63' + str(x) + '59685', 22) + int('17' + str(x) + '53', 22) + int('36' + str(x) + '5', 22)
    if c%21 == 0 and x == 4:
        print(int(c/21))
#Ответ: 729929407.