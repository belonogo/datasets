sugoma = []
for s1 in range(1, 10):
    for s2 in range(10):
        for s3 in range(10):
            for s4 in range(10):
                Sus1 = int(str(s1) + str(s2) + str(s3) + str(s4))
                sugoma.append(Sus1)
                sugoma.sort()
                sum1, sum2, sum3 = s1 + s2, s2 + s3, s3 + s4
                sumsum = [sum1, sum2, sum3]
                sumsum.sort()
                Sus2 = int(str(sumsum[1]) + str(sumsum[2]))
                if Sus2 == 1315:
                    print(sugoma[-1])
#Ответ: 9676.