for x in range(16):
    c = int('1' + str(x) + 'BAD', 16) + int('2C' + str(x) + 'FE', 16)
    if c%15==0 and x==6:
        print(int(c/15))
#Ответ: 18341.