for x in range(12):
    c = int('3' + str(x) + 'DA', 14)+int('5' + str(x) + 'A6', 12)
    if c%81==0:
        print(int(c/81))
#Ответ: 250.