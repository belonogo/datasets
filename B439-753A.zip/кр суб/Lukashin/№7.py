for x in range(8):
    for y in range(8):
        a = int(str(y) + '04' + str(x) + '5', 11)
        b = int('253' + str(x) + str(y), 8)
        c = a + b
        if c%117 == 0:
            print(int(c/117))
#Ответ: 224.