c = 0
for s1 in 'КОНФЕТА':
    for s2 in 'КОНЕТА':
        for s3 in 'КОНФЕТА':
            for s4 in 'КОНФЕТА':
                for s5 in 'КОНФЕТА':
                    s = s1+s2+s3+s4+s5
                    if s.count('Е') == 2:
                        #print(s)
                        c+=1
print(c)
#Ответ: 1944.