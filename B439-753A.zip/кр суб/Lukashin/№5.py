C = 'ЯРОСЛАВ'
glas = [i for i in 'ЯОА']
sogl = [i for i in 'РСЛВ']
c = 0
for s1 in C:
    for s2 in C:
        for s3 in C:
            for s4 in C:
                for s5 in C:
                    s = s1 + s2 + s3 + s4 + s5
                    if s.count('Я') <= 1 and s.count('Р') <= 1 and s.count('О') <= 1 and s.count('С') <= 1 and s.count(
                            'Л') <= 1 and s.count('А') <= 1 and s.count('В') <= 1:
                        if (s.count(sogl[0]) + s.count(sogl[1]) + s.count(sogl[2]) + s.count(sogl[3])) > 2:
                            if s.count('ЯО' or 'ЯА' or 'ОА' or 'ОЯ' or 'АО' or 'АЯ') == 0:
                                print(s)
                                c += 1
print(c)
# Ответ: 1704
