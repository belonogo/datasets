for n in range(100):
    s=bin(n)[2:]
    s=str(s)
    if n %3==0:
        s+=s[-3:]
    else:
        k=(n%3)*3
        s+=bin(k)[2:]
    r=int(s,2)
    if r>=76:
        print (n)
        break
