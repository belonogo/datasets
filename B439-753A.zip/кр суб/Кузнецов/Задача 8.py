a='0123456789'
for x in a:  
    f = int('3'+x+'DA',14)+int('5'+x+'A'+'6',12)
    if f%81==0:
        print(f//81)
        break

