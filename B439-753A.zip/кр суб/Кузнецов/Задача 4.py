from itertools import product
alph = 0
for p in product('КОНФЕТА',repeat=5):
    if p.alph('Е')==2 and p(1)!='ф':
        alph+=1
print(alph)
