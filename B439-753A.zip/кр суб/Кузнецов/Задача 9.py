a='0123456789ABCDEF'
for x in a:  
    f = int('1'+x+'BAD',16)+int('2'+'C'+x+'FE',16)
    if f%15==0:
        print(f//15)
        break

