alph='ОЛЬГА'
count=0
for a1 in alph:
    for a2 in alph:
        for a3 in alph:
            for a4 in alph:
                for a5 in alph:
                    count+=1
                    if a1=='О' and a1=='Л' and a1=='Ь' and a1=='Г' and a1=='А':
                        print(count)

