alph='ЯРОСЛАВ'
count=0
for a1 in alph:
    for a2 in alph:
        for a3 in alph:
            for a4 in alph:
                for a5 in alph:
                    res=a1+a2+a3+a4+a5
                    if res.count('Я')<=1 and res.count('Р')<=1 and res.count('О')<=1 and res.count('С')<=1 and res.count('Л')<=1 and res.count('А')<=1 and res.count('В')<=1 and\
                       res.count('Р')+res.count('С')+res.count('Л')+res.count('В')>res.count('О')+res.count('Я')+res.count('А')and\
                       res.count('ЯО')==0 and res.count('ЯА')==0 and res.count('ОА')==0 and res.count('ОЯ')==0 and res.count('АЯ')==0 and res.count('АЯ')==0:
                        count+=1
print(count)
