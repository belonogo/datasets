a='0123456789ABCDEFGHIJKL'
for x in a:  
    f = int('63'+x+'59685',22)+int('17'+x+'53',22)+int('36'+x+'5',22)
    if f%21==0:
        print(f//21)
        break

