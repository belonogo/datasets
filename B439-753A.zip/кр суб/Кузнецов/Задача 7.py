a='01234567'
for x in a:
    for y in a:
        f = int(f'{y}04{x}5',11)+int(f'253{x}{y}',8)
        if f%117==0:
            print(f//117)

