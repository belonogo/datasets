a=set()
for n in range(1,150):
    s=bin(n)[2:]
    if n%3==0:
        s+=s[len(s)-3:]
    if n%3!=0:
        k=(n%3)*3
        s1=bin(k)[2:]
        s+=s1
    r=int(s,2)
    if r>151:
        a.add(r)
print(min(a))
