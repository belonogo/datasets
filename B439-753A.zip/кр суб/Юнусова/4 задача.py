from itertools import product
s=0
for n in product('КОНФЕТА', repeat=5):
    if n.count('Е')==2 and n[1]!='Ф':
        s+=1
print(s)
