r_list=[]
a='0123456789ABCDEF'
for x in a:
    op1=int('1'+x+'BAD',16)
    op2=int('2'+'C'+x+'FE',16)
    r=op1+op2
    if r%15==0:
        r_list.append(r//15)
print(min(r_list))
