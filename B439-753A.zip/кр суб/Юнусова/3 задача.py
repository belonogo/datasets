for i in range(1000, 10000):
    s=str(i)
    sum12=int(s[0])+int(s[1])
    sum23=int(s[1])+int(s[2])
    sum34=int(s[2])+int(s[3])
    k=str(sum12+sum23+sum34 - max(sum12,sum23,sum34) - min(sum12,sum23,sum34))
    n= str(max(sum12,sum23,sum34))
    s1=k+n
    if s1=='1315':
        print(i)
        break
