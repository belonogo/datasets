r_list=[]
a='01234567'
for x in a:
    for y in a:
        op1=int(y+'04'+x+'5', 11)
        op2=int('253'+x+y, 8)
        r=op1+op2
        if r%117==0:
            r_list.append(r//117)
print(min(r_list))
