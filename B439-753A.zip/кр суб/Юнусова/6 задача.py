from itertools import product
k=0
for i in product('АГЛОЬ', repeat=5):
    a=''.join(i)
    k+=1
    if a=='ОЛЬГА':
        print(k)
        break
