a='0123456789'
for x in a:
    op1=int('3'+x+'DA',14)
    op2=int('5'+x+'A'+'6',12)
    r=op1+op2
    if r%81==0:
        print(r//81)
        break
