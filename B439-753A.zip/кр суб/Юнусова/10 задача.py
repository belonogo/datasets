a='0123456789ABCDEFGHIJKL'
for x in a:
    op1=int('63'+x+'59685',22)
    op2=int('17'+x+'53',22)
    op3=int('36'+x+'5',22)
    r=op1+op2+op3
    if r%21==0:
        print(r//21)
        break
