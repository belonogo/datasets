import sys
sys.setrecursionlimit(10**6)
def F(n):
    if n>1000000:
        return(n)
    if n<=1000000:
        return(n+F(2*n))
def G(n):
    return (F(n)/n)
res=[]
a=0
for N in range (1,100000):
    if G(N)==G(1000):
        a+=1
        res.append(a)
print(max(res))
Ответ:977
