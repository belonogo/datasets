for n in range(1000000,1,-1):
    r5=bin(n)[2:]
    if n%5==0:
        r5+=bin(5)[2:]
    else:
        r5+='1'
    if int(r5,2)%7==0:
        r5+=bin(7)[2:]
    else:
        r5+='1'
    r=int(r5,2)
    if r<1855663:
        print(n)
        break
Ответ:463913
