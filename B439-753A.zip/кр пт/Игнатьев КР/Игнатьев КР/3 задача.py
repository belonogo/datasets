res=[]
for n in range(10000):
    d=bin(n)[2::]
    if n%3==0:
        d+=d[-3:]
    else:
        d+=bin((n%3)*3)[2::]
    a=int(d,2)
    if a<=137:
        res.append(a)
print(max(res))
Ответ:127
