import sys
sys.setrecursionlimit(10**6)
def F(n):
    if n>1000000:
        return n
    if n<=1000000:
        return n+F(2*n)
def G(n):
        return F(n)/n

res=0
for a in range(1, 1000000):
    if G(a)==G(1000):
        res=res+1
print(res)
