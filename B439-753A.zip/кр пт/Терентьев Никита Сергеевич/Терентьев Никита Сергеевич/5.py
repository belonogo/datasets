res=[]
for N in range (10000000):
    D=bin(N)[2::]
    if N%5==0:
        D+=bin(5)[2::]
    else:
        D+='1'
    if int(D,2)%7==0:
        D+=bin(7)[2::]
    else:
        D+='1'
    R=int(D, 2)
    if R<1855663:
        res.append(N)
print(max(res))

