import sys
sys.setrecursionlimit(10**6)
def F(n):
    if n<11:
        return 10
    if n>=11:
        return n+F(n-1)
print (F(2124)/F(2122))
