res=[]
for N in range (1000):
    D=bin(N)[2::]
    if N%3==0:
        D+=D[-3:]
    else:
        D+=bin((N%3)*3)[2::]
    R=int(D, 2)
    if R<137:
        res.append(R)
    
print(max(res))
