import sys
sys.setrecursionlimit(10**6)
def f(n):
    if n > 1000000:
        return(n)
    if n <= 1000000:
        return(n + f(2 * n))
def g(n):
    return(f(n) / n)

res = []
a = 0
for n in range (1,1000000):
    if g(n) == g(1000):
        a += 1
        res.append(a)
print(max(res))

#Ответ: 977