for n in range(1000000,1, -1):
    d = bin(n)[2:]
    if n % 5 == 0:
        d +=bin(5)[2:]
    else:
        d += '1'
    if int(d, 2) % 7 == 0:
        d += bin(7)[2:]
    else:
        d += '1'
    r = int(d, 2)
    if r < 1855663:
        print(n)
        break

#Ответ: 463913