res = []
for n in range(10000):
    d = bin(n)[2::]
    if n % 3 == 0:
        d += d[-3:]
    else:
        d += bin((n % 3) * 3)[2::]
    r = int(d, 2)
    if r <= 137:
        res.append(r)
print(max(res))

#Ответ: 127