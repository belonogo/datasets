#1
R = 0
for i in range(1, 1000):
    k = bin(i)[2:]
    if i % 3 == 0:
        k += k[-3:]
    else:
        k += bin(( i % 3) * 3 // 2) [2:]
        s = int(k, 2)
        if s >  151:
            R += 1
print(R)


#2
def F(n):
    if n >= 1000:
        return 1000
    if n < 1000 and n % 2 != 0:
        return n*F(n + 1)
    if n < 1000 and n % 2 == 0:
        return n * (F*(n+1) / 2)
print(" ")
print(F(998 / 1001))


#3
R = 0
for i in range(1, 1000):
    k = bin(i)[2:]
    if i % 3 == 0:
        k += k[-3:] 
        s = int(k, 2)
        if s < 151:
            R += 1
print(" ")
print(R)


#4
def F(n):
    if n < 11:
        return 10
    if n >= 11:
        return n+F*(n-1)
print(" ")
print(F(2124 - 2122))


#5
for n in range(100000, 1, -1):
    r = bin(i)[2:]
    if i % 5 == 0:
        r += bin(5)[2:]
    else:
        r += "1"
    if int(r,2) % 7 == 0:
        r += bin(7)[2:]
    else:
        r += "1"
    if int(r, 2) < 1855663:
        print('')
        print(n)
        break
        
